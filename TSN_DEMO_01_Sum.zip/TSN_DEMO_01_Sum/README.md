# TSN_DEMO_01_Sum
Сумма двух цифр
![Screenshot](screenshot.png)

